// RequireJS module for jQuery which returns global jQuery to avoid conflicts.
define([], function() {
	return jQuery;
});
